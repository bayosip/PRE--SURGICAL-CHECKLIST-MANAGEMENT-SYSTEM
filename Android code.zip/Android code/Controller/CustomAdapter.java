package com.example.adebayo.Controller;

/**
 * Created by Adebayo on 03/03/2015.
 */

import android.content.Context;
import android.text.format.Time;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.EditText;

import java.util.ArrayList;

import Model.AnswerTimeStamp;
import Model.AnswersComments;
import Model.DatabaseAdapter;
import Model.LogonData;
import Model.ToastMessage;

public class CustomAdapter extends ArrayAdapter< String> {

    Context context;
    String patientname, whoLoggedIn, answer = "";
    DatabaseAdapter dbHandler;
    String[] itemlist, anstimes;
    View customView;
    ArrayList<String> itemlist_qstn = new ArrayList<String>();
    AnswersComments anscom;
    AnswerTimeStamp timeAns;
    ViewHolder vHolder;
    LogonData actionLogs;
    Time today = new Time();
    String nameOfTreat;



    public CustomAdapter(Context context, ArrayList<String> questions, String[] Ans,
                         String pName, String sName, String tName, String[] aTimes) {
        super(context, R.layout.custom_row_p_check_list, questions);
        dbHandler = new DatabaseAdapter(context);
        this.context = context;
        itemlist_qstn = questions;
        itemlist = Ans;
        anstimes = aTimes;
        anscom = new AnswersComments();
        patientname = pName;
        whoLoggedIn = sName;
        nameOfTreat = tName;
        timeAns = new AnswerTimeStamp();
        actionLogs = new LogonData();

    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {

            convertView = mInflater.inflate(R.layout.custom_row_p_check_list, null);
            customView= convertView;
            vHolder = new ViewHolder();
            vHolder.eachQuestions = (TextView) convertView.findViewById(R.id.textViewQuestion);
            vHolder.comments = (EditText) convertView.findViewById(R.id.editTextComments);
            vHolder.lastUpdated = (TextView) convertView.findViewById(R.id.textViewLastUpdated);
            vHolder.yesNoGroup = (RadioGroup) convertView.findViewById(R.id.radioGroupYesNo);
            vHolder.saveButton = (Button) customView.findViewById(R.id.buttonSave);
            vHolder.editButton = (Button) convertView.findViewById(R.id.buttonEdit);
            vHolder.yesRButton = (RadioButton) convertView.findViewById(R.id.radioButtonYes);
            vHolder.noRButton = (RadioButton) convertView.findViewById(R.id.radioButtonNo);
            vHolder.naRButton = (RadioButton) convertView.findViewById(R.id.radioButtonNa);

            convertView.setTag(vHolder);

        }
        else {
            vHolder = (ViewHolder) convertView.getTag();
        }

        String qstion = itemlist_qstn.get(position);


        vHolder.eachQuestions.setText(qstion);

            String comments = itemlist[position+1];
        String ansTimeStamped = anstimes[position+1];
        String[] updateDetails = dbHandler.getSingleLogData(ansTimeStamped);


            //ToastMessage.message(context,comments);
        vHolder.comments.setText(comments);
        if(comments.equals("Pending")){
            vHolder.saveButton.setText("SAVE");
        }
        else {
            vHolder.saveButton.setText("UPDATE");

        }
        vHolder.lastUpdated.setText("Last Updated: " + updateDetails[0] + " "+ updateDetails[1]);

        if (comments.startsWith("Yes")){
            vHolder.yesRButton.setChecked(true);
        }
        else if (comments.startsWith("Not")){
            vHolder.naRButton.setChecked(true);
        }
        else if (comments.startsWith("No")){
            vHolder.noRButton.setChecked(true);
        }



        vHolder.yesNoGroup.setOnCheckedChangeListener(rgListner);
        vHolder.saveButton.setOnClickListener(saveButtonListener);
        vHolder.editButton.setOnClickListener(editButtonListener);
        return convertView;
    }

    private RadioGroup.OnCheckedChangeListener rgListner = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {


            int id = group.getCheckedRadioButtonId();
            if (id == R.id.radioButtonYes) {
                answer = "Yes";

            } else if (id == R.id.radioButtonNo) {
                answer = "No";
                //ToastMessage.message(context, answer);
            } else if (id == R.id.radioButtonNa) {
                answer = "Not Applicable";
                //ToastMessage.message(context, answer);
            }


        }
    };

    /*This method records the answer on each question and inserts into the database*/
   private void addAnswersComments(int pos, String ans, String name) {

       anscom.setAnswers(ans);
       long id = dbHandler.addAnswers(anscom, pos, name);
       if (id <=0){
           ToastMessage.message(context,"error in saving answer!");
       }
       else {
           ToastMessage.message(context, "Saved successfully!!!");
       }
   }

    private String setTimeStamp(){
        today.setToNow();
        String  timestamp = today.format("%Y-%m-%d %H:%M");
        return  timestamp;
    }

    /**This method records to the log class what question was answered
    * who answered each question, the patient name and the timestamp
    * */
     private  void accountForTask(int pos, String bName){

        actionLogs.setPatientName(patientname);
        actionLogs.setStaffName(whoLoggedIn);
        actionLogs.setTimeStamp(setTimeStamp());
        if (bName.equals("SAVE")){
        actionLogs.setActionTaken("Question " + String.valueOf(pos+1)+ " Answered");
        }
        else if (bName.equals("UPDATE")){
            actionLogs.setActionTaken("Question " + String.valueOf(pos+1)+ " Updated");
        }
         dbHandler.addLogins(actionLogs);

    }


    public void setTimestampForEachAns(AnswerTimeStamp time, int pos, String name){

        time.setTreatmentName(name);
        time.setTimeStamp(setTimeStamp());
        dbHandler.addAnswersTimesStamp(time, pos, name);
    }

    @Override
    public int getPosition(String item) {
        return super.getPosition(item);
    }

    private View.OnClickListener editButtonListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                View parentRow = (View) v.getParent();
                EditText edittext = (EditText)parentRow.findViewById(R.id.editTextComments);
                Button b = (Button) parentRow.findViewById(R.id.buttonSave);

                edittext.setEnabled(true);
                b.setEnabled(true);
                v.setEnabled(false);
            }
        };

  private View.OnClickListener saveButtonListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View parentRow = (View) v.getParent();

                ListView listView = (ListView) parentRow.getParent();
                final int pos = listView.getPositionForView(parentRow);
                Button b = (Button) parentRow.findViewById(R.id.buttonSave);
                EditText et = (EditText) parentRow.findViewById(R.id.editTextComments);
                        et.setEnabled(false);

                parentRow.findViewById(R.id.buttonEdit).setEnabled(true);
                String buttonName = b.getText().toString();
                b.setEnabled(false);
                if(b.getText().toString().equals("SAVE")){

                    b.setText("UPDATE");
                }
                String fullAnswer = answer + ": " + et.getText().toString();
                addAnswersComments(pos, fullAnswer,
                        (patientname));
                setTimestampForEachAns(timeAns, pos,(patientname));
                accountForTask(pos, buttonName);
            }
        };

   public class ViewHolder{

        TextView eachQuestions, lastUpdated;
        EditText comments;
        RadioGroup yesNoGroup;
        Button saveButton;
        Button editButton;
        RadioButton yesRButton, noRButton, naRButton;
    }
}
