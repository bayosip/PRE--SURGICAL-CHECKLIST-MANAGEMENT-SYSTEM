package com.example.adebayo.Controller;

import android.content.Context;
import android.text.format.Time;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import Model.DatabaseAdapter;
import Model.LogonData;
import Model.Treatment;

/**
 * Created by Adebayo on 08/04/2015.
 */
public class CustomTreatmentAdapter extends ArrayAdapter<String[]>  {

    Context context;
    DatabaseAdapter dbHandler;
    ArrayList<String[]> itemList = new ArrayList<String[]>();
    String[] treatmentInfo;
    String str, whoLoggedIn;
    LogonData actionLogs;
    ViewHolder holder;
    Treatment treat;
    Time today = new Time();
    /**
     * Constructor
     *
     * @param context  The current context.
     * @param objects  The objects to represent in the ListView.
     */
    public CustomTreatmentAdapter(Context context, ArrayList<String[]> objects, String loggedIn) {
        super(context, R.layout.custom_row_treatment, objects);

        this.context = context;
        this.itemList = objects;
         actionLogs = new LogonData();
        treat = new Treatment();
            whoLoggedIn = loggedIn;
        dbHandler = new DatabaseAdapter(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null){

            convertView = mInflater.inflate(R.layout.custom_row_treatment, null);

            holder = new ViewHolder();
            holder.treatment = (TextView) convertView.findViewById(R.id.textViewTreatmentName);
            holder.category = (TextView) convertView.findViewById(R.id.textViewCategory);
            holder.alarm = (TextView) convertView.findViewById(R.id.textViewAlarm);

            convertView.setTag(holder);
        }
        else {
            holder = (ViewHolder) convertView.getTag();
        }

         treatmentInfo = itemList.get(position);


        holder.treatment.setText(treatmentInfo[1]);
        str = treatmentInfo[1];
        holder.category.setText(treatmentInfo[2]);
        holder.alarm.setText(treatmentInfo[5]);

        return convertView;
    }



    public class ViewHolder {
        TextView treatment, alarm, category;
    }
}
