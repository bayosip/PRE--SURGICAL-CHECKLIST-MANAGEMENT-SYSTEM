package com.example.adebayo.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by ao43 on 25/03/15.
 */
public class DataCollector {

    /*
    * Loads each drop down list item with patient information
    * */
    public static  HashMap<String, List<String>> getInfo(String[] data){

        List<String> listHeader = new ArrayList<String>();
        HashMap<String, List<String>> details = new HashMap<String, List<String>>();
        listHeader.add("Personal details");
        listHeader.add("Patient Anatomy");
        listHeader.add("Patient Handling");

       String pDetails = "Name: " + data[0]+ "\n" +
               "Age: " + data[1] + "\n" +
                "Sex: " + data[2] + "\n" +
                "Date of Birth: " + data[3];

        String pAnatomy = "Height: " +data[7]+ "cm\n" +
                "Weight: "+data[8] + "kg\n" +
                "Blood Type: "+data[10];

       String pHandler = "Parent/Guardian: " + data[4]+ "\n" +
                "Ward: "+data[5] + "\n" +
               "Assigned Doctor: "+data[6] + "\n" +
                "Diagnosis: "+data[9] + "\n";
        List<String> patientDets = new ArrayList<String>();
        patientDets.add(pDetails);

        List<String> patientAna = new ArrayList<String>();
        patientAna.add(pAnatomy);

        List<String> patientHand = new ArrayList<String>();
        patientHand.add(pHandler);

        details.put(listHeader.get(0), patientDets); // Header, Child data
        details.put(listHeader.get(1), patientAna);
        details.put(listHeader.get(2), patientHand);

        return  details;
    }
}
