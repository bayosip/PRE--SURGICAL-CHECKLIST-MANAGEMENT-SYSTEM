package com.example.adebayo.Controller;

import java.util.HashMap;
import java.util.List;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;


/**
 * Created by Adebayo on 18/03/2015.
 */
public class ExpandableCustomAdapter extends  BaseExpandableListAdapter  {

    private Context _context;
    private List<String> _listHeader;
    HashMap<String, List<String>> details;
    // header titles
    // child data in format of header title, child title

    public ExpandableCustomAdapter(Context context, List<String> listHeader,
                                 HashMap<String, List<String>> listChildData) {
        this._context = context;
        this._listHeader = listHeader;
        this.details = listChildData;
    }

    @Override
    public Object getChild(int groupPosition, int childPosititon) {
        return this.details.get(this._listHeader.get(groupPosition))
                .get(childPosititon);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getChildView(int groupPosition, final int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {

        final String childText = (String) getChild(groupPosition, childPosition);

        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this._context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.custom_row_p_hist, null);
        }

        TextView txtListChild = (TextView) convertView
                .findViewById(R.id.textViewAboutPatient);

        txtListChild.setText(childText);
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return false;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return this.details.get(this._listHeader.get(groupPosition))
                .size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return this._listHeader.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return this._listHeader.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        String headerTitle = (String) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this._context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.list_group, null);
        }

        TextView ListHeader = (TextView) convertView
                .findViewById(R.id.textViewHeader);
        ListHeader.setTypeface(null, Typeface.BOLD);
        ListHeader.setText(headerTitle);

        return convertView;
    }
}
