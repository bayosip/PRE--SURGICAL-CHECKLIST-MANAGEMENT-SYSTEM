package com.example.adebayo.Controller;


import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.format.Time;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import Model.DatabaseAdapter;
import Model.ToastMessage;


public class HomeScreen extends ActionBarActivity {

    //private static final String logMessageTag;
    String _username, _password;
    Context context = this;
    Time today = new Time(Time.getCurrentTimezone());

  /*  static {
        logMessageTag = "State log:";
    }*/

    EditText userName, passWord;
    Button loginButton;
    DatabaseAdapter dbHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
         dbHandler = new DatabaseAdapter(context);
        createButton();
    }

    //Create button and its functions

    private void createButton(){
        loginButton = (Button) findViewById(R.id.loginButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                userName = (EditText) findViewById(R.id.userNameText);
                passWord = (EditText) findViewById(R.id.passWordText);

                _username = userName.getText().toString();
                _password = passWord.getText().toString();

                String[] staffInfo = dbHandler.getStaffInfo(_username);

                    if (_password.equals(staffInfo[3]))
                    {
                        startActivity(new Intent(HomeScreen.this,
                                PatientOptionScreen.class).putExtra("Staff Name", staffInfo[0]));
                        setBlank();
                        ToastMessage.message(context, "Login Successful, Welcome");
                    }
                    else {
                        Toast.makeText(getApplicationContext(),
                                "Login unsuccessful, Try again", Toast.LENGTH_SHORT).show();
                    }
            }
        });
    }
    private String setTimeStamp(){
        today.setToNow();
        String  timestamp = today.format("%Y-%m-%d %H:%M:%S");
        return  timestamp;
    }

    private void setBlank(){

        userName.setText("");
        passWord.setText("");
    }


    @Override
    public void onBackPressed() {
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_home_screen, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        switch(item.getItemId()){

            case R.id.exitLink:

                finish();
                System.exit(0);
                return  true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
