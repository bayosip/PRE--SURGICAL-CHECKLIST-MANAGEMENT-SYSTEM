package com.example.adebayo.Controller;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import java.util.ArrayList;

import Model.AnswersComments;
import Model.DatabaseAdapter;
import Model.ToastMessage;


public class PatientCheckList extends ActionBarActivity {


    Context context = this;
    DatabaseAdapter dbHandler;
    //List<String> questions = new ArrayList<String>();
    TextView eachQuestions;
    EditText comments;
    RadioGroup yesNoGroup;
    Button saveButton;
    Button editButton;
    TextView loadedComments;
    ViewSwitcher switcher;
    RadioButton r1 , r2 , r3;
    AnswersComments anscom;

    String Answer ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_check_list);
        dbHandler = new DatabaseAdapter(context);
        anscom = new AnswersComments();
        checkListSetup();
    }

    private void checkListSetup(){

        Bundle patientData = getIntent().getExtras();
        if (patientData == null){
            return;
        }

        final String treatmentName = patientData.getString("Treatment Name");
        final String patientName = patientData.getString("Patient Name") + ": "+
                treatmentName;
        final String staffName = patientData.getString("Staff Name");
        final String category = patientData.getString("Treatment Category");

        TextView name = (TextView) findViewById(R.id.textViewName);
        name.setText(patientName);
        //anscom.setPatientName(patientName);

        String[] questionList =  dbHandler.getAllChecklistQuestions(category);
        ArrayList<String> questions= new ArrayList<String>();
        for (int i =0; i<questionList.length; i++){
            questions.add(questionList[i]);
        }

        String[] AnswerCom = dbHandler.getAllChecklistAnswers(patientName);
        String[] AnswerTimes = dbHandler.getAllAnswerTimes(patientName);
        if(questions.size()!=0) {
            ListView listView = (ListView) findViewById(R.id.listViewChecklist);
            ListAdapter adapter = new CustomAdapter(context,questions, AnswerCom, patientName, staffName,
                    treatmentName, AnswerTimes);
            listView.setAdapter(adapter);
        }
        else{

            ToastMessage.message(context, "No questions setup yet!");
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_patient_check_in, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        switch(item.getItemId()){

            case R.id.PatientManagementOptionLink:
                startActivity(new Intent(PatientCheckList.this, PatientOptionScreen.class));
                return  true;
            case R.id.logOutLink:
                Intent logOut = new Intent(PatientCheckList.this, HomeScreen.class);
                logOut.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(logOut);
                finish();
                return  true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}



