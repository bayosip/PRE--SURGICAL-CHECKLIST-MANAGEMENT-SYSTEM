package com.example.adebayo.Controller;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TabHost;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import Model.DatabaseAdapter;


public class PatientInformation extends ActionBarActivity {


    TabHost tabHistory;
    ExpandableListAdapter listAdapter;
    ExpandableListView expListView;
    List<String> dataPatient;
    HashMap<String, List<String>> patientInfo;
    DatabaseAdapter dbHandler;
    TextView namePatient, cancerAnswer, treatmentAnswer, currentMedsAns, otherMedsAns;
    Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_history);

        dbHandler = new DatabaseAdapter(context);

        tabSetup();
        widgetsSetup();
    }

    private void tabSetup(){

        tabHistory = (TabHost) findViewById(R.id.tabHost);
        tabHistory.setup();

        TabHost.TabSpec tabSpec = tabHistory.newTabSpec("Personal Info");

        tabSpec.setContent(R.id.tabPersonalInfo);
        tabSpec.setIndicator("Personal Info");
        tabHistory.addTab(tabSpec);

        tabSpec = tabHistory.newTabSpec("Past Medical History");
        tabSpec.setContent(R.id.tabPastMedicalHist);
        tabSpec.setIndicator("Past Medical History");
        tabHistory.addTab(tabSpec);

    }

    private void widgetsSetup(){

        Bundle patientData = getIntent().getExtras();

        if (patientData == null){
            return;
        }

        final String patientName = patientData.getString("Patient Name");
        namePatient = (TextView) findViewById(R.id.nameTextView);
        cancerAnswer = (TextView) findViewById(R.id.textViewCancerAnswer);
        treatmentAnswer = (TextView) findViewById(R.id.textViewTreatmentAnswer);
        currentMedsAns = (TextView) findViewById(R.id.textViewCurrentMeds);
        otherMedsAns = (TextView) findViewById(R.id.textViewOtherMeds);

        namePatient.setText(patientName);
        String[] info = dbHandler.getPatientInfoName(patientName);

        expListView = (ExpandableListView) findViewById(R.id.patientInfolistView);

        // preparing list data
        patientInfo = DataCollector.getInfo(info);
        dataPatient = new ArrayList<String>(patientInfo.keySet());

        listAdapter = new ExpandableCustomAdapter(this, dataPatient, patientInfo);

        cancerAnswer.setText(info[11]);
        treatmentAnswer.setText(info[12]);
        currentMedsAns.setText(info[13]);
        otherMedsAns.setText(info[14]);
        // setting list adapter
        expListView.setAdapter(listAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_patient_history, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {

            case R.id.PatientManagementOptionLink:
                startActivity(new Intent(PatientInformation.this, PatientOptionScreen.class));
                return true;
            case R.id.logOutLink:
                Intent logOut = new Intent(PatientInformation.this, HomeScreen.class);
                logOut.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(logOut);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
