package com.example.adebayo.Controller;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class PatientOptionScreen extends ActionBarActivity {

    Button newPatient, registeredPatient, viewManagement;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_option_screen);
        createbuttons();
    }

    private String getWhoLoggedIn (){

        Bundle extra = getIntent().getExtras();

        if (extra == null){
            return null;
        }

        String staffName = extra.getString("Staff Name");
        return  staffName;
    }

    //create the functions of the two buttons
    private void createbuttons(){


        newPatient = (Button) findViewById(R.id.newButton);

        newPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PatientOptionScreen.this,
                        CheckInNewPatient.class).putExtra("Staff Name", getWhoLoggedIn()));
                Toast.makeText(getApplicationContext(),
                        "New Patient", Toast.LENGTH_SHORT).show();
            }
        });

        registeredPatient = (Button) findViewById(R.id.registeredButton);

        registeredPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PatientOptionScreen.this, SearchPatient.class)
                        .putExtra("Staff Name", getWhoLoggedIn()));
                Toast.makeText(getApplicationContext(),
                        "Registered Patient", Toast.LENGTH_SHORT).show();
            }
        });
        viewManagement = (Button) findViewById(R.id.viewStaffActivitiesButton);

        viewManagement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PatientOptionScreen.this, ViewAllActivities.class));
                Toast.makeText(getApplicationContext(),
                        "Management List", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_patient_option_screen, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {

            case R.id.logOutLink:
                Intent logOut = new Intent(PatientOptionScreen.this, HomeScreen.class);
                logOut.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(logOut);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
