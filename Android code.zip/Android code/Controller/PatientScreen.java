package com.example.adebayo.Controller;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


public class PatientScreen extends ActionBarActivity {

     TextView name;
    Context context =this;
    Bundle extras;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_screen);
        extras = new Bundle();
        listSetup();
    }

    private String getWhoLoggedIn (){

        Bundle extra = getIntent().getExtras();

        if (extra == null){
            return null;
        }
        final String staffName = extra.getString("Staff Name");
        return  staffName;
    }

    private void listSetup(){
        Bundle patientData = getIntent().getExtras();

        if (patientData == null){
            return;
        }

       final String patientName = patientData.getString("Patient Name");

        name = (TextView) findViewById(R.id.nameTextView);
        name.setText(patientName);
        final String[] list= {"Patient Information", "Patient Treatment","Examination",
                "Check out patient",};
    //convert String array into list using a list adapter
        ListAdapter listAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, list);
        ListView listView = (ListView) findViewById(R.id.patientScrnListView);
        listView.setAdapter(listAdapter);
    //Handles what happens when an item on the list is clicked
        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String list = String.valueOf(parent.getItemAtPosition(position));

                        Toast.makeText(PatientScreen.this, list, Toast.LENGTH_LONG).show();
                        extras.putString("Patient Name", patientName);
                        extras.putString("Staff Name", getWhoLoggedIn());

                        if(position == 0){
                            startActivity(new Intent(PatientScreen.this, PatientInformation.class)
                                    .putExtras(extras));
                        }
                        else if (position == 1){

                            startActivity(new Intent(PatientScreen.this, PatientTreatment.class)
                                    .putExtras(extras));
                        }
                        else if (position == 2){

                        }
                    }
                }
        );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_patient_screen, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {

            case R.id.PatientManagementOptionLink:
                startActivity(new Intent(PatientScreen.this, PatientOptionScreen.class));
                return true;
            case R.id.logOutLink:
                Intent logOut = new Intent(PatientScreen.this, HomeScreen.class);
                logOut.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(logOut);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
