package com.example.adebayo.Controller;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.Time;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.ArrayList;
import java.util.Calendar;

import Model.AnswerTimeStamp;
import Model.AnswersComments;
import Model.DatabaseAdapter;
import Model.LogonData;
import Model.ToastMessage;
import Model.Treatment;


public class PatientTreatment extends ActionBarActivity {

    EditText treatmentName,treatmentDescription;
    Button addTreatment, setClock;
    TextView patientName, eachTreatment, eachCategory, eachAlarm;
    RadioGroup treatCategory;
    Context context = this;
    ListView listViewTreatment;
    String whatToDo;
    Treatment treat;
    AnswersComments anscom;
    AnswerTimeStamp timeAns;
    DatabaseAdapter dbHandler;
    private int setHour, setMin, setDay, setMonth, setYear;
    String time, date, treatmentCategory;
    Bundle extras;
    LogonData staffLog;
    Time today;
    Calendar c = Calendar.getInstance();

   int notificationID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treatment);

        treat = new Treatment();
        anscom = new AnswersComments();
        timeAns = new AnswerTimeStamp();
        staffLog = new LogonData();
        today = new Time();
        dbHandler = new DatabaseAdapter(context);
        extras = new Bundle();
        widgetSetup();
        listSetUp(getpatientName());
        NotificationManager notificationManager = (NotificationManager)getSystemService(context.NOTIFICATION_SERVICE);
        notificationManager.cancel(notificationID);
    }

    private String getWhoLoggedIn (){

        Bundle patientData = getIntent().getExtras();
        if (patientData == null){
            return null;
        }
        String staffName = patientData.getString("Staff Name");
        return  staffName;
    }

    private String setTimeStamp(){
        today.setToNow();
        String  timestamp = today.format("%Y-%m-%d %H:%M");
        return  timestamp;
    }


    private String getpatientName(){
        Bundle patientData = getIntent().getExtras();
        if (patientData == null){
            return null;
        }
         final String patient_Name = patientData.getString("Patient Name");
        return patient_Name;
    }

    private void widgetSetup(){

        patientName = (TextView) findViewById(R.id.textViewT_Name);
        treatmentName = (EditText) findViewById(R.id.editTextaAddTreatment);
        treatmentDescription = (EditText) findViewById(R.id.editTextTreatmentDescription);
        addTreatment = (Button) findViewById(R.id.buttonAddTreatment);
        setClock = (Button) findViewById(R.id.buttonSetClock);
        treatCategory = (RadioGroup) findViewById(R.id.radioGroupTreatmentCategory);

        patientName.setText(getpatientName());

        treatmentName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                    setClock.setEnabled(!treatmentName.getText().toString().trim().isEmpty());}

            @Override
            public void afterTextChanged(Editable s) {}
        });

        treatCategory.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton scan = (RadioButton) findViewById(R.id.radioButtonAddTreatScan);
                RadioButton lineInsertion = (RadioButton) findViewById(R.id.radioButtonAddTreatLineInsertion);
                RadioButton surgery = (RadioButton) findViewById(R.id.radioButtonAddTreatSurgery);

                if (scan.isChecked()) {
                    treatmentCategory = "Scan";
                    ToastMessage.message(context, treatmentCategory);
                } else if (lineInsertion.isChecked()) {
                    treatmentCategory = "Line Insertion";

                } else if (surgery.isChecked()) {
                    treatmentCategory = "Surgery";
                }
            }
        });
        setClock.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {


                new DatePickerDialog(PatientTreatment.this,listener, c.get(Calendar.YEAR),
                        c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();

                new TimePickerDialog(PatientTreatment.this, listenerTime, c.get(Calendar.HOUR_OF_DAY),
                        c.get(Calendar.MINUTE),true).show();
                addTreatment.setEnabled(true);
            }
        });

        //Button Click event that store entered treatment details in database
        addTreatment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setTreatment(getpatientName(), getWhoLoggedIn());
                dbHandler.addPatientTreatment(treat);
                listSetUp(getpatientName());

                ToastMessage.message(context, "Reminder set for : " + date + ", " + time);
                String treatmentAndPName = getpatientName() + ": " + treatmentName.getText().toString();
                anscom.setPatientName(treatmentAndPName);
                timeAns.setTreatmentName(treatmentAndPName);
                dbHandler.insertNameAnswers(anscom);
                dbHandler.insertNameAnswerTimes(timeAns);
                staffLog.setStaffName(getWhoLoggedIn());
                staffLog.setTimeStamp(setTimeStamp());
                staffLog.setPatientName(getpatientName());
                staffLog.setActionTaken("Added " + treatmentName.getText().toString()
                        + " for:" + getpatientName());
                dbHandler.addLogins(staffLog);
                notificationID = setSharedPreference();
                clear();
            }
        });
    }

    /**
     * This method sets up a reminder for each treatment added
     *
     */

   private  void setReminder (int Hour, int Min, int Year, int Month, int Day  ){

       extras.putInt("Notification ID", notificationID);
        Intent intent = new Intent(PatientTreatment.this, ReminderService.class).putExtras(extras);
        AlarmManager reminderManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        startService(intent);
        PendingIntent pending = PendingIntent.getService(context,0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);

       Calendar calendar = Calendar.getInstance();
       calendar.set(Calendar.HOUR_OF_DAY, Hour);
       calendar.set(Calendar.MINUTE, Min);
       calendar.set(Calendar.SECOND, 0);
       calendar.add(Calendar.DAY_OF_MONTH, Day);
       calendar.add(Calendar.MONTH, Month);
       calendar.add(Calendar.YEAR, Year);

        reminderManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pending);
    }

    /*
    * This method sets a new notification id for every treatment per patient
    * */
    private int setSharedPreference (){

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        int i = preferences.getInt("Notification ID", 1000);
        setReminder(setHour, setMin, setYear, setMonth, setDay);
         i++;
        editor.putInt("Notification ID", i);
        editor.commit();

        return i;

    }


    private  void setTreatment(String patient, String addStaff) {
      if (!TextUtils.isEmpty(treatmentName.getText().toString())) {
          treat.setPatientName(patient);
          treat.setStaffNameAdd(addStaff);
          treat.setTreatmentName(treatmentName.getText().toString());
          treat.setTreatmentCategory(treatmentCategory);
          treat.setTreatmentDescription(treatmentDescription.getText().toString());
          treat.setTimeStamp(date + " " + time );
      }
    }


    DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener(){

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

            int yearCurrent = c.get(Calendar.YEAR);
            int monthCurrent = c.get(Calendar.MONTH);
            int dayCurrent = c.get(Calendar.DAY_OF_MONTH);

            int yrdiff = year - yearCurrent;

            if (yrdiff < 0) {
                ToastMessage.message(context, "Wrong Year! minimum year: " + String.valueOf(yearCurrent));
            }
            else {

                if (yrdiff == 0) {
                    int monthDiff = (monthOfYear)  - monthCurrent;

                    if (monthDiff < 0) {

                        ToastMessage.message(context, "Wrong Month! minimum Month: " + String.valueOf(monthCurrent));
                    } else {
                        int dayDiff = dayOfMonth - dayCurrent;

                        if (dayDiff < 0){
                            ToastMessage.message(context, "Wrong Day! minimum Day: " + String.valueOf(dayCurrent));
                        }else {
                            setYear = year;
                            setMonth = monthOfYear+1;
                            setDay = dayOfMonth;
                            date = new StringBuilder().append(setYear) + "-" + String.valueOf(pad(setMonth))
                                    + "-" + String.valueOf(pad(setDay)).toString();
                        }
                    }
                }else {

                    setYear = year;
                    setMonth = monthOfYear+1;
                    setDay = dayOfMonth;
                    date = new StringBuilder().append(setYear) + "-" + String.valueOf(pad(setMonth))
                            + "-" + String.valueOf(pad(setDay)).toString();
                }
            }
        }};

    TimePickerDialog.OnTimeSetListener listenerTime = new TimePickerDialog.OnTimeSetListener() {

        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

            int hourCurrent = c.get(Calendar.HOUR_OF_DAY);
            int minCurrent = c.get(Calendar.MINUTE);

            int hrDiff = hourOfDay - hourCurrent;

            if (hrDiff<0){
                ToastMessage.message(context, "Wrong Hour, minimum Hour: " + String.valueOf(hourCurrent));

            }
            else{

                if (hrDiff == 0){
                    int minDiff = minute - minCurrent;
                    if (minDiff < 0){
                        ToastMessage.message(context, "Wrong Minutes, minimum Minutes: " + String.valueOf(minCurrent));
                    }
                    else{
                        setHour = hourOfDay;
                        setMin = minute;
                        time = new StringBuilder().append(pad(setHour)) + ":" + String.valueOf(pad(setMin)).toString();
                    }
                }
                setHour = hourOfDay;
                setMin = minute;
                time = new StringBuilder().append(pad(setHour)) + ":" + String.valueOf(pad(setMin)).toString();
            }

        }
    };

    private void listSetUp(String str){
        final ArrayList< String[]> PatientTreatmentList =  dbHandler.getAllTreatment(str);

            listViewTreatment = (ListView) findViewById(R.id.listView_P_Treatment);
            ListAdapter adapter = new CustomTreatmentAdapter(context, PatientTreatmentList, getWhoLoggedIn());
            listViewTreatment.setAdapter(adapter);

        listViewTreatment.setOnItemClickListener( new AdapterView.OnItemClickListener(){
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            eachTreatment = (TextView) view.findViewById(R.id.textViewTreatmentName);

                            String treatName = eachTreatment.getText().toString();
                            String treatMore[] = PatientTreatmentList.get(position);
                            extras.putString("Treatment Category", treatMore[2]);
                            extras.putString("Patient Name", getpatientName());
                            extras.putString("Staff Name", getWhoLoggedIn());
                            extras.putString("Treatment Name", treatName);

                            String message = treatMore[0] + "\n" + treatMore[2] + "\n" + treatMore[3] + "\n" +
                                    treatMore[4] + "\n" + treatMore[5];
                            callAlertDialog(treatName, message);


                        }
                    });

    }

    private void callAlertDialog(String nameOfTreatment, String treatmentMessage){
        // Show The Dialog with Selected treatment info
        AlertDialog dialog = new AlertDialog.Builder(context).create();
        dialog.setTitle(nameOfTreatment);
        dialog.setIcon(android.R.drawable.ic_dialog_info);
        dialog.setMessage(treatmentMessage);
        dialog.setButton(DialogInterface.BUTTON_POSITIVE,"OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                        startActivity(new Intent(PatientTreatment.this, PatientCheckList.class)
                                .putExtras(extras));
                        return;
                    }
                }) ;

        dialog.show();
    }

    private void clear(){

        treatmentName.setText("");
        treatmentDescription.setText("");
        addTreatment.setEnabled(false);
    }

    //Pad date and time less than 10 with a 0 in front
    private static String pad(int c) {
        if (c >= 10)
            return String.valueOf(c);
        else
            return "0" + String.valueOf(c);
    }


            @Override
            public boolean onCreateOptionsMenu(Menu menu) {
                // Inflate the menu; this adds items to the action bar if it is present.
                getMenuInflater().inflate(R.menu.menu_treatment, menu);
                return true;
            }

            @Override
            public boolean onOptionsItemSelected(MenuItem item) {
                // Handle action bar item clicks here. The action bar will
                // automatically handle clicks on the Home/Up button, so long
                // as you specify a parent activity in AndroidManifest.xml.
                switch (item.getItemId()) {

                    case R.id.PatientManagementOptionLink:
                        startActivity(new Intent(PatientTreatment.this, PatientOptionScreen.class));
                        return true;
                    case R.id.logOutLink:
                        Intent logOut = new Intent(PatientTreatment.this, HomeScreen.class);
                        logOut.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(logOut);
                        finish();
                        return true;
                    default:
                        return super.onOptionsItemSelected(item);
                }
            }

}
