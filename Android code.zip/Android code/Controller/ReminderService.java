package com.example.adebayo.Controller;

/**
 * Created by ao43 on 17/04/15.
 */

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.IBinder;

import Model.ToastMessage;

public class ReminderService extends Service {

    boolean isNotificationActive = false;
    NotificationManager noteManager;


    /**
     * Return the communication channel to the service.  May return null if
     * clients can not bind to the service.  The returned
     * {@link android.os.IBinder} is usually for a complex interface
     * that has been <a href="{@docRoot}guide/components/aidl.html">described using
     * aidl</a>.
     * <p/>
     * <p><em>Note that unlike other application components, calls on to the
     * IBinder interface returned here may not happen on the main thread
     * of the process</em>.  More information about the main thread can be found in
     * <a href="{@docRoot}guide/topics/fundamentals/processes-and-threads.html">Processes and
     * Threads</a>.</p>
     *
     * @param intent The Intent that was used to bind to this service,
     *               as given to {@link android.content.Context#bindService
     *               Context.bindService}.  Note that any extras that were included with
     *               the Intent at that point will <em>not</em> be seen here.
     * @return Return an IBinder through which clients can call on to the
     * service.
     */
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        ToastMessage.message(this.getApplicationContext(), " Service called");

        final String whomToAdminTo;
        final int notificationID = (Integer) intent.getExtras().get("Notification ID");
        whomToAdminTo = (String) intent.getExtras().get("Patient Name");


        noteManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Intent intent1 = new Intent(this.getApplicationContext(), HomeScreen.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 , intent1,
                0);

        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        int icon = R.drawable.ic_launcher;
        String tickerText= "Patient Treatment Alert";
        String title = "Administer Treatment!!!";
        String contentText = "Please administer treatment for " + whomToAdminTo;

        Notification notify = new Notification.Builder(this)
                .setContentTitle(title)
                .setContentText(contentText)
                .setTicker(tickerText)
                .setSmallIcon(icon)
                .setSound(sound)
                .setContentIntent(pendingIntent)
                .build();

        noteManager.notify(notificationID, notify);

        isNotificationActive = true;
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    //Change String values to numbers
    private int integerParser (String str){
        int parser = 0;
        try {

            parser = Integer.parseInt(str);

        } catch(NumberFormatException nfe) {
            System.out.println("Could not parse " + nfe);
        }
        return  parser;
    }
}
