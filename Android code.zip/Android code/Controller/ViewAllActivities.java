package com.example.adebayo.Controller;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

import Model.DatabaseAdapter;
import Model.ToastMessage;


public class ViewAllActivities extends ActionBarActivity {

    EditText searchName;
    Button searchButton;
    Context context = this;
    DatabaseAdapter dbHandler;
    ListView activityList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_activities);
        dbHandler = new DatabaseAdapter(context);

        declareWidgets();
    }

    private void declareWidgets(){

        searchName = (EditText) findViewById(R.id.editTextNameSearch);
        searchButton = (Button) findViewById(R.id.buttonViewAllSearch);
        activityList = (ListView)findViewById(R.id.listViewActivities);

        searchName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                listSetup(activityList);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchButton.setEnabled(!searchName.getText().toString().trim().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        listSetup(activityList);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = searchName.getText().toString().toUpperCase();
                ArrayList<String[]>  mylist = dbHandler.getLogData(name);

                if (!mylist.isEmpty()){
                viewActivityAdapter viewPatientAdapter = new viewActivityAdapter(context,
                        R.layout.custom_row_view_all_activities, mylist);
                activityList.setAdapter(viewPatientAdapter);
                }

                else {
                    ToastMessage.message(context, "Patient Not Found");
                }
            }
        });
    }

    private void listSetup( ListView listView){

        ArrayList<HashMap<String, String>> mylist = dbHandler.getAllLogData();

        SimpleAdapter viewAllAdapter = new SimpleAdapter(context, mylist, R.layout.custom_row_view_all_activities,
                new String[] {"StaffName", "PatientName", "ActionTaken", "AnswerTimeStamp"},
                new int[] {R.id.textView_staff,  R.id.textView_Patient, R.id.textView_Action,
                        R.id.textView_Time});
        listView.setAdapter(viewAllAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_view_all_activities, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.PatientManagementOptionLink:
                startActivity(new Intent(ViewAllActivities.this, PatientOptionScreen.class));
                return true;
            case R.id.logOutLink:
                Intent logOut = new Intent(ViewAllActivities.this, HomeScreen.class);
                logOut.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(logOut);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
