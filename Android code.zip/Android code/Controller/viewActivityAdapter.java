package com.example.adebayo.Controller;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by ao43 on 20/04/15.
 */
public class viewActivityAdapter extends ArrayAdapter<String[]> {

    ArrayList <String[]> activities;
    ViewAllHolder holder;
    Context context;
    String[] patientActivities;

    public viewActivityAdapter(Context context, int layout, ArrayList<String[]> viewList) {
        super(context,layout, viewList);

        this.context = context;
        activities =viewList;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null){

            convertView = mInflater.inflate(R.layout.custom_row_view_all_activities, null);

            int id[] = new int[] {R.id.textView_staff,  R.id.textView_Patient, R.id.textView_Action,
                    R.id.textView_Time};

            holder = new ViewAllHolder();
            holder.staffName = (TextView) convertView.findViewById(id[0]);
            holder.patientName = (TextView) convertView.findViewById(id[1]);
            holder.action = (TextView) convertView.findViewById(id[2]);
            holder.timeStamp = (TextView) convertView.findViewById(id[3]);

            convertView.setTag(holder);
        }
        else {
            holder = (ViewAllHolder) convertView.getTag();
        }

        patientActivities = activities.get(position);

        holder.staffName.setText(patientActivities[0]);
        holder.patientName.setText(patientActivities[1]);
        holder.action.setText(patientActivities[2]);
        holder.timeStamp.setText(patientActivities[3]);
        return convertView;
    }

    private  static class ViewAllHolder{

      TextView staffName, patientName, action, timeStamp;

    }

}
