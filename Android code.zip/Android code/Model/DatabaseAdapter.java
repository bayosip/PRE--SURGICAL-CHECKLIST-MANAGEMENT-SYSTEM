package Model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Adebayo on 15/02/2015.
 */
public class DatabaseAdapter  {


    DataBaseHandler handler;
    boolean notNull = false;


    //Adding new rows to each table in database
    Context context;

    public DatabaseAdapter(Context context) {
        this.context =context;
        this.handler = new DataBaseHandler(context);
        this.handler.getWritableDatabase();
    }

    public long addPatient(Patient patient){
        try{
        ContentValues values = new ContentValues();
        SQLiteDatabase db = handler.getWritableDatabase();

        values.put(handler.KEY_PI_NAME, patient.getPatientName());
        values.put(handler.KEY_PI_AGE, patient.getPatientAge());
        values.put(handler.KEY_PI_SEX, patient.getPatientSex());
        values.put(handler.KEY_PI_DOB, patient.getPatientDOB());
        values.put(handler.KEY_PI_GUARDIAN, patient.getPatientGuardian());
        values.put(handler.KEY_PI_WARD, patient.getPatientWard());
        values.put(handler.KEY_PI_DOCTOR, patient.getPatientDoctor());
        values.put(handler.KEY_PI_HEIGHT, patient.getPatientHeight());
        values.put(handler.KEY_PI_WEIGHT, patient.getPatientWeight());
        values.put(handler.KEY_PI_DIAGNOSIS, patient.getPatientDiagnosis());
        values.put(handler.KEY_PI_BLOOD, patient.getPatientBloodType());
        values.put(handler.KEY_PI_PREVIOUS_CANCER, patient.getPreviousCancer());
        values.put(handler.KEY_PI_PREVIOUS_TREATMENT, patient.getPreviousTreatment());
        values.put(handler.KEY_PI_CURRENT_MED, patient.getCurrentMedication());
        values.put(handler.KEY_PI_OTHER_MED, patient.getOtherMedication());

        Log.d("Database Operation", "Registration Successful");
        long id = db.insert(handler.TABLE_PATIENT_INFO, null, values);
        return  id;}
        catch (SQLiteException e){
            Log.d("Database Operation", "Error: "+e);
            return 0;
        }
    }


    public long addPatientTreatment (Treatment treat){
       try {
           ContentValues values = new ContentValues();
           SQLiteDatabase db = handler.getWritableDatabase();

           values.put(handler.KEY_TREATMENT_PATIENT_NAME, treat.getPatientName());
           values.put(handler.KEY_TREATMENT_STAFF_NAME_ADD, treat.getStaffNameAdd());
           values.put(handler.KEY_TREATMENT_CATEGORY, treat.getTreatmentCategory());
           values.put(handler.KEY_TREATMENT_NAME, treat.getTreatmentName());
           values.put(handler.KEY_TREATMENT_DESCRIPTION, treat.getTreatmentDescription());
           values.put(handler.KEY_TREATMENT_TODO_DATE, treat.getTimeStamp());
           long id = db.insert(handler.TABLE_TREATMENT, null, values);

           return id;
       }catch(SQLiteException e){
           Log.d("Database Operation", "Error: "+e);
               return 0;
           }
    }

    public long insertNameAnswers (AnswersComments answersComments){
        try {
            ContentValues values = new ContentValues();

            SQLiteDatabase db = handler.getWritableDatabase();

            String[] COLUMN_NAMES_ANS = {handler.KEY_ANSWERS_NAME, handler.KEY_ANSWERS1, handler.KEY_ANSWERS2,
                    handler.KEY_ANSWERS3, handler.KEY_ANSWERS4, handler.KEY_ANSWERS5, handler.KEY_ANSWERS6,
                    handler.KEY_ANSWERS7, handler.KEY_ANSWERS8, handler.KEY_ANSWERS9, handler.KEY_ANSWERS10, handler.KEY_ANSWERS11};

            values.put(COLUMN_NAMES_ANS[0], answersComments.getPatientName());
            values.put(COLUMN_NAMES_ANS[1], "Pending");
            values.put(COLUMN_NAMES_ANS[2], "Pending");
            values.put(COLUMN_NAMES_ANS[3], "Pending");
            values.put(COLUMN_NAMES_ANS[4], "Pending");
            values.put(COLUMN_NAMES_ANS[5], "Pending");
            values.put(COLUMN_NAMES_ANS[6], "Pending");
            values.put(COLUMN_NAMES_ANS[7], "Pending");
            values.put(COLUMN_NAMES_ANS[8], "Pending");
            values.put(COLUMN_NAMES_ANS[9], "Pending");
            values.put(COLUMN_NAMES_ANS[10], "Pending");
            values.put(COLUMN_NAMES_ANS[11], "Pending");
            long id = db.insert(handler.TABLE_ANSWERS, null, values);


            return id;
        }catch(SQLiteException e){
            Log.d("Database Operation", "Error: "+e);
            return 0;
        }
    }

    public  long insertNameAnswerTimes (AnswerTimeStamp time){
        try {
            ContentValues values = new ContentValues();

            SQLiteDatabase db = handler.getWritableDatabase();
            String[] COLUMN_NAMES_ANS_TIME = {handler.KEY_TIMESTAMP_NAME, handler.KEY_TIMESTAMP1,
                    handler.KEY_TIMESTAMP2, handler.KEY_TIMESTAMP3, handler.KEY_TIMESTAMP4,
                    handler.KEY_TIMESTAMP5, handler.KEY_TIMESTAMP6, handler.KEY_TIMESTAMP7,
                    handler.KEY_TIMESTAMP8, handler.KEY_TIMESTAMP9, handler.KEY_TIMESTAMP10,
                    handler.KEY_TIMESTAMP11};

            values.put(COLUMN_NAMES_ANS_TIME[0],time.getTreatmentName());
            values.put(COLUMN_NAMES_ANS_TIME[1], "Pending");
            values.put(COLUMN_NAMES_ANS_TIME[2], "Pending");
            values.put(COLUMN_NAMES_ANS_TIME[3], "Pending");
            values.put(COLUMN_NAMES_ANS_TIME[4], "Pending");
            values.put(COLUMN_NAMES_ANS_TIME[5], "Pending");
            values.put(COLUMN_NAMES_ANS_TIME[6], "Pending");
            values.put(COLUMN_NAMES_ANS_TIME[7], "Pending");
            values.put(COLUMN_NAMES_ANS_TIME[8], "Pending");
            values.put(COLUMN_NAMES_ANS_TIME[9], "Pending");
            values.put(COLUMN_NAMES_ANS_TIME[10], "Pending");
            values.put(COLUMN_NAMES_ANS_TIME[11], "Pending");
            long id = db.insert(handler.TABLE_TIMESTAMP, null, values);

            return id;
        }catch(SQLiteException e){
            Log.d("Database Operation", "Error: "+e);
            return 0;
        }
    }


    public long addAnswers(AnswersComments ansCom, int pos, String name){
        try {
            ContentValues values = new ContentValues();
            SQLiteDatabase db = handler.getWritableDatabase();
            String[] COLUMN_NAMES_ANS = {handler.KEY_ANSWERS_NAME, handler.KEY_ANSWERS1, handler.KEY_ANSWERS2,
                    handler.KEY_ANSWERS3, handler.KEY_ANSWERS4, handler.KEY_ANSWERS5, handler.KEY_ANSWERS6,
                    handler.KEY_ANSWERS7, handler.KEY_ANSWERS8, handler.KEY_ANSWERS9, handler.KEY_ANSWERS10, handler.KEY_ANSWERS11};
            values.put(COLUMN_NAMES_ANS[pos+1], ansCom.getAnswers());

            //String query = "UPDATE " + handler.TABLE_ANSWERS + " SET " + COLUMN_NAMES_ANS[position+1]
            // +" ='"+answers+"' WHERE "+ COLUMN_NAMES_ANS[1] +" = " + name;
            //db.execSQL(query);
            long rowID = db.update(handler.TABLE_ANSWERS, values, COLUMN_NAMES_ANS[0] + " =?",
                    new String[]{name});

            ToastMessage.message(context, "Database Operation: Answer updated Successful to "
                    + "Answer" + String.valueOf(pos+1));
            return  rowID;
        }catch(SQLiteException e){
            Log.d("Database Operation", "Error: "+e);
            return 0;
        }

 }

    public long addAnswersTimesStamp(AnswerTimeStamp time, int pos, String name){

        try {
            ContentValues values = new ContentValues();
            SQLiteDatabase db = handler.getWritableDatabase();


            String[] COLUMN_NAMES = { handler.KEY_TIMESTAMP_NAME, handler.KEY_TIMESTAMP1,
                    handler.KEY_TIMESTAMP2, handler.KEY_TIMESTAMP3, handler.KEY_TIMESTAMP4,
                    handler.KEY_TIMESTAMP5, handler.KEY_TIMESTAMP6, handler.KEY_TIMESTAMP7,
                    handler.KEY_TIMESTAMP8, handler.KEY_TIMESTAMP9, handler.KEY_TIMESTAMP10,
                    handler.KEY_TIMESTAMP11};

            values.put(COLUMN_NAMES[pos +1], time.getTimeStamp());
            long id = db.update(handler.TABLE_TIMESTAMP, values, COLUMN_NAMES[0] + " =?",
                    new String[]{name});

            return id;
        }catch (SQLiteException e){
            Log.d("Database Operation", "Error: "+e);
            return 0;
        }
    }

    public void addLogins(  LogonData logonData){
        ContentValues values = new ContentValues();
        SQLiteDatabase db = handler.getWritableDatabase();
        values.put(handler.KEY_LOGS_SNAME, logonData.getStaffName());
        values.put(handler.KEY_LOGS_PNAME, logonData.getPatientName());
        values.put(handler.KEY_LOGS_TIMESTAMP, logonData.getTimeStamp());
        values.put(handler.KEY_LOGS_ACTION, logonData.getActionTaken());

        db.insert(handler.TABLE_LOGINS, null, values);

    }
    public String[] getPatientInfoName(String name){
        SQLiteDatabase db = handler.getReadableDatabase();
        String[] COLUMN_NAMES = { handler.KEY_PI_NAME, handler.KEY_PI_AGE,
                handler.KEY_PI_SEX, handler.KEY_PI_DOB, handler.KEY_PI_GUARDIAN, handler.KEY_PI_WARD
                , handler.KEY_PI_DOCTOR, handler.KEY_PI_HEIGHT, handler.KEY_PI_WEIGHT, handler.KEY_PI_DIAGNOSIS
                , handler.KEY_PI_BLOOD, handler.KEY_PI_PREVIOUS_CANCER, handler.KEY_PI_PREVIOUS_TREATMENT,
                handler.KEY_PI_CURRENT_MED, handler.KEY_PI_OTHER_MED};

        Cursor cursor = db.query(handler.TABLE_PATIENT_INFO, COLUMN_NAMES, handler.KEY_PI_NAME + " = '" +
                name + "'", null, null, null, null);
        String [] info=  new String[COLUMN_NAMES.length];
        while (cursor.moveToNext()) {
            info[0]= cursor.getString(cursor.getColumnIndex(handler.KEY_PI_NAME));
            info[1]= cursor.getString(cursor.getColumnIndex(handler.KEY_PI_AGE));
            info[2]= cursor.getString(cursor.getColumnIndex(handler.KEY_PI_SEX));
            info[3]= cursor.getString(cursor.getColumnIndex(handler.KEY_PI_DOB));
            info[4]= cursor.getString(cursor.getColumnIndex(handler.KEY_PI_GUARDIAN));
            info[5]= cursor.getString(cursor.getColumnIndex(handler.KEY_PI_WARD));
            info[6]= cursor.getString(cursor.getColumnIndex(handler.KEY_PI_DOCTOR));
            info[7]= cursor.getString(cursor.getColumnIndex(handler.KEY_PI_HEIGHT));
            info[8]= cursor.getString(cursor.getColumnIndex(handler.KEY_PI_WEIGHT));
            info[9]= cursor.getString(cursor.getColumnIndex(handler.KEY_PI_DIAGNOSIS));
            info[10]= cursor.getString(cursor.getColumnIndex(handler.KEY_PI_BLOOD));
            info[11]= cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[11]));
            info[12]= cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[12]));
            info[13]= cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[13]));
            info[14]= cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[14]));
        }
        return  info;
    }

    /**This method accesses the TABLE_QUESTIONS table from database
    * and reads the values in column KEY_Q3 and returns these
    * values as an ArrayList<String> Object
    * */
    public String [] getAllChecklistQuestions( String treatCategory) {


        SQLiteDatabase db = handler.getReadableDatabase();

        String[] COLUMN_NAMES = { handler.KEY_Q1, handler.KEY_Q2,
                handler.KEY_Q3, handler.KEY_Q4, handler.KEY_Q5, handler.KEY_Q6,handler.KEY_Q7,
                handler.KEY_Q8, handler.KEY_Q9, handler.KEY_Q10, handler.KEY_Q11};
        Cursor cursor = db.query(handler.TABLE_QUESTIONS, COLUMN_NAMES, handler.KEY_PATIENT_NAME + " ='"+
                        treatCategory + "'", null, null, null, null);
    String[] questionList = new String[COLUMN_NAMES.length];

            //move cursor through table till there are no more questions
            while (cursor.moveToNext()) {
                questionList[0] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[0]));
                questionList[1] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[1]));
                questionList[2] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[2]));
                questionList[3] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[3]));
                questionList[4] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[4]));
                questionList[5] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[5]));
                questionList[6] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[6]));
                questionList[7] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[7]));
                questionList[8] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[8]));
                questionList[9] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[9]));
                questionList[10] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[10]));
        }
        // return pre-surgery questions
        return questionList;
        }

    public String[] getAllChecklistAnswers(String name) {


        SQLiteDatabase db = handler.getReadableDatabase();

        String[] COLUMN_NAMES = { handler.KEY_ANSWERS_NAME,  handler.KEY_ANSWERS1,  handler.KEY_ANSWERS2, handler.KEY_ANSWERS3,
                handler.KEY_ANSWERS4,  handler.KEY_ANSWERS5,  handler.KEY_ANSWERS6,  handler.KEY_ANSWERS7,
                handler.KEY_ANSWERS8,  handler.KEY_ANSWERS9, handler.KEY_ANSWERS10, handler.KEY_ANSWERS11};

        Cursor cursor = db.query(handler.TABLE_ANSWERS, COLUMN_NAMES, handler.KEY_ANSWERS_NAME  + " ='"+
                name + "'",null, null, null, null);

        String[] answerList = new String[COLUMN_NAMES.length];

        while (cursor.moveToNext()) {
                answerList[0] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS_NAME));
                answerList[1] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS1)) ;
                answerList[2] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS2));
                answerList[3] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS3));
                answerList[4] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS4));
                answerList[5] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS5));
                answerList[6] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS6));
                answerList[7] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS7));
                answerList[8] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS8));
                answerList[9] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS9));
                answerList[10] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS10));
                answerList[11] = cursor.getString(cursor.getColumnIndex(handler.KEY_ANSWERS11));
            }

        // return answers
        return answerList;
    }

    public String[] getAllAnswerTimes(String name) {


        SQLiteDatabase db = handler.getReadableDatabase();

        String[] COLUMN_NAMES = { handler.KEY_TIMESTAMP_NAME, handler.KEY_TIMESTAMP1,
                handler.KEY_TIMESTAMP2, handler.KEY_TIMESTAMP3, handler.KEY_TIMESTAMP4,
                handler.KEY_TIMESTAMP5, handler.KEY_TIMESTAMP6, handler.KEY_TIMESTAMP7,
                handler.KEY_TIMESTAMP8, handler.KEY_TIMESTAMP9, handler.KEY_TIMESTAMP10,
                handler.KEY_TIMESTAMP11};

        Cursor cursor = db.query(handler.TABLE_TIMESTAMP, COLUMN_NAMES, handler.KEY_TIMESTAMP_NAME  + " ='"+
                name + "'",null, null, null, null);

        String[] ansTimeStampList = new String[COLUMN_NAMES.length];

        while (cursor.moveToNext()) {

            ansTimeStampList[0] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP_NAME));
            ansTimeStampList[1] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP1)) ;
            ansTimeStampList[2] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP2));
            ansTimeStampList[3] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP3));
            ansTimeStampList[4] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP4));
            ansTimeStampList[5] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP5));
            ansTimeStampList[6] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP6));
            ansTimeStampList[7] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP7));
            ansTimeStampList[8] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP8));
            ansTimeStampList[9] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP9));
            ansTimeStampList[10] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP10));
            ansTimeStampList[11] = cursor.getString(cursor.getColumnIndex(handler.KEY_TIMESTAMP11));
        }

        // return answers
        return ansTimeStampList;
    }

    public String[] getStaffInfo(String user){

        SQLiteDatabase db = handler.getReadableDatabase();

        String[] column_NamesHS = {handler.KEY_STAFF_NAME, handler.KEY_STAFF_ROLE, handler.KEY_STAFF_USER_NAME,
                handler.KEY_STAFF_PASS_WORD};

        Cursor cursor = db.query(handler.TABLE_STAFF, column_NamesHS, handler.KEY_STAFF_USER_NAME + " = '" + user + "'"
                , null, null, null, null);

        String[] staff = new String[column_NamesHS.length];
        while (cursor.moveToNext()){
            staff[0] = cursor.getString(cursor.getColumnIndex(handler.KEY_STAFF_NAME));
            staff[1] = cursor.getString(cursor.getColumnIndex(handler.KEY_STAFF_ROLE));
            staff[2] = cursor.getString(cursor.getColumnIndex(handler.KEY_STAFF_USER_NAME));
            staff[3] = cursor.getString(cursor.getColumnIndex(handler.KEY_STAFF_PASS_WORD));
        }
        return  staff;
    }



    public ArrayList<String[]> getAllTreatment(String name) {

        ArrayList<String[]> treatmentList;
        treatmentList = new ArrayList<String[]>();
        SQLiteDatabase db = handler.getReadableDatabase();

        String[] COLUMN_NAMES = {handler.KEY_TREATMENT_PATIENT_NAME, handler.KEY_TREATMENT_STAFF_NAME_ADD
                , handler.KEY_TREATMENT_CATEGORY, handler.KEY_TREATMENT_NAME, handler.KEY_TREATMENT_DESCRIPTION,
                handler.KEY_TREATMENT_TODO_DATE};

        Cursor cursor = db.query(handler.TABLE_TREATMENT, COLUMN_NAMES, handler.KEY_TREATMENT_PATIENT_NAME
                + " = '" + name + "'", null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                String[] map = new String[]{cursor.getString(cursor.getColumnIndex(handler.KEY_TREATMENT_PATIENT_NAME))
                        , cursor.getString(cursor.getColumnIndex(handler.KEY_TREATMENT_NAME))
                        , cursor.getString(cursor.getColumnIndex(handler.KEY_TREATMENT_CATEGORY))
                        , cursor.getString(cursor.getColumnIndex(handler.KEY_TREATMENT_DESCRIPTION))
                        , cursor.getString(cursor.getColumnIndex(handler.KEY_TREATMENT_STAFF_NAME_ADD))
                        , cursor.getString(cursor.getColumnIndex(handler.KEY_TREATMENT_TODO_DATE))};
                treatmentList.add(map);
            } while (cursor.moveToNext());
        }
        return treatmentList;
    }

    public ArrayList<String[]> getLogData( String patientName){

        try {
            ArrayList <String[]> patientActivity ;
            patientActivity= new ArrayList<String[]>();
            SQLiteDatabase db = handler.getReadableDatabase();


            String[] COLUMN_NAMES ={handler.KEY_LOGS_SNAME, handler.KEY_LOGS_PNAME,
                     handler.KEY_LOGS_ACTION, handler.KEY_LOGS_TIMESTAMP};

            Cursor cursor = db.query(handler.TABLE_LOGINS, COLUMN_NAMES,
                    handler.KEY_LOGS_PNAME+ "='"+ patientName +"'",
                    null, null, null, null);
            if (cursor.moveToFirst()) {
                do {

                    String[] map = new String[]{cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[0])),
                            cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[1])),
                            cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[2])),
                            cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[3]))};
                    patientActivity.add(map);
                }while (cursor.moveToNext());
            }

            return  patientActivity;

        }catch (SQLiteException e){

            ToastMessage.message(context, "Error "+ e);
            Log.d("Database Operation", "Error: "+e);
            return null;
        }
    }

    public String[] getSingleLogData( String patientTime){

        try {
            SQLiteDatabase db = handler.getReadableDatabase();

            String[] COLUMN_NAMES ={handler.KEY_LOGS_SNAME
                    , handler.KEY_LOGS_TIMESTAMP};

            Cursor cursor = db.query(handler.TABLE_LOGINS, COLUMN_NAMES,
                    handler.KEY_LOGS_TIMESTAMP+ "='"+ patientTime +"'",
                    null, null, null, null);

                String[] patientActivity= new String[COLUMN_NAMES.length];
                while (cursor.moveToNext()){
                    patientActivity[0] =cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[0]));
                    patientActivity[1] = cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[1]));
                }

            return  patientActivity;

        }catch (SQLiteException e){
            Log.d("Database Operation", "Error: "+e);

            return null;
        }
    }

    public ArrayList<HashMap<String, String>> getAllLogData( ){

        SQLiteDatabase db = handler.getReadableDatabase();
        ArrayList <HashMap<String, String>> allActivities = new ArrayList<HashMap<String, String>>();

        String[] COLUMN_NAMES ={handler.KEY_LOGS_SNAME, handler.KEY_LOGS_PNAME,
                handler.KEY_LOGS_TIMESTAMP, handler.KEY_LOGS_ACTION};
        Cursor cursor = db.query(handler.TABLE_LOGINS, COLUMN_NAMES, null, null, null, null, null);

        while (cursor.moveToNext()){

            HashMap<String,String> map = new HashMap<String, String>();

            map.put(COLUMN_NAMES[0], cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[0])));
            map.put(COLUMN_NAMES[1], cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[1])));
            map.put(COLUMN_NAMES[2], cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[2])));
            map.put(COLUMN_NAMES[3], cursor.getString(cursor.getColumnIndex(COLUMN_NAMES[3])));
            allActivities.add(map);
        }
        return  allActivities;

    }




        static class DataBaseHandler extends  SQLiteOpenHelper {

            private static final int DATABASE_VERSION = 7;

            private static final String DATABASE_NAME = "Patient Info.db";

            private static final String TABLE_PATIENT_INFO = "PATIENT_INFO";
            private static final String TABLE_QUESTIONS = "HO_QUESTIONS";
            private static final String TABLE_ANSWERS = "ANSWERS";
            private static final String TABLE_COMMENTS =  "COMMENTS";
            private static final String TABLE_STAFF = "HOSPITAL_STAFF";
            private static final String TABLE_LOGINS = "LOGINS";
            private static final String TABLE_TREATMENT = "PATIENT_TREATMENT";
            private static final String TABLE_TIMESTAMP = "TIMESTAMP";

            private static final String KEY_PI_ID = "_patientID";
            private static final String KEY_PI_NAME = "patientName";
            private static final String KEY_PI_AGE = "patientAge";
            private static final String KEY_PI_SEX = "patientSex";
            private static final String KEY_PI_DOB = "patientDOB";
            private static final String KEY_PI_GUARDIAN = "patientGuardian";
            private static final String KEY_PI_WARD = "patientWard";
            private static final String KEY_PI_DOCTOR = "patientDoctor";
            private static final String KEY_PI_HEIGHT = "patientHeight";
            private static final String KEY_PI_WEIGHT = "patientWeight";
            private static final String KEY_PI_DIAGNOSIS = "patientDiagnosis";
            private static final String KEY_PI_BLOOD = "patientBloodType";
            private static final String KEY_PI_PREVIOUS_CANCER = "PreviousIllness";
            private static final String KEY_PI_PREVIOUS_TREATMENT = "PreviousTreatment";
            private static final String KEY_PI_CURRENT_MED = "CurrentMedication";
            private static final String KEY_PI_OTHER_MED = "OtherMedication";

            private static final String KEY_PATIENT_NAME = "Category";
            private static final String KEY_Q1 = "Question1";
            private static final String KEY_Q2 = "Question2";
            private static final String KEY_Q3 = "Question3";
            private static final String KEY_Q4 = "Question4";
            private static final String KEY_Q5 = "Question5";
            private static final String KEY_Q6 = "Question6";
            private static final String KEY_Q7 = "Question7";
            private static final String KEY_Q8 = "Question8";
            private static final String KEY_Q9 = "Question9";
            private static final String KEY_Q10 = "Question10";
            private static final String KEY_Q11 = "Question11";

            private static final String KEY_ANSWERS_NAME = "patientName";
            private static final String KEY_ANSWERS1 = "ans1";
            private static final String KEY_ANSWERS2 = "ans2";
            private static final String KEY_ANSWERS3 = "ans3";
            private static final String KEY_ANSWERS4 = "ans4";
            private static final String KEY_ANSWERS5 = "ans5";
            private static final String KEY_ANSWERS6 = "ans6";
            private static final String KEY_ANSWERS7 = "ans7";
            private static final String KEY_ANSWERS8 = "ans8";
            private static final String KEY_ANSWERS9 = "ans9";
            private static final String KEY_ANSWERS10 = "ans10";
            private static final String KEY_ANSWERS11 = "ans11";



            private static final String KEY_LOGS_SNAME = "StaffName" ;
            private static final String KEY_LOGS_PNAME = "PatientName";
            private static final String KEY_LOGS_TIMESTAMP = "AnswerTimeStamp";
            private static final String KEY_LOGS_ACTION = "ActionTaken";

            private static final String KEY_STAFF_NAME ="Name";
            private static final String KEY_STAFF_ROLE = "Role";
            private static final String KEY_STAFF_USER_NAME = "Username";
            private static final String KEY_STAFF_PASS_WORD = "Password";


            private static final String KEY_TREATMENT_PATIENT_NAME = "PatientName";
            private static final String KEY_TREATMENT_CATEGORY = "TreatmentCategory";
            private static final String KEY_TREATMENT_NAME = "TreatmentName";
            private static final String KEY_TREATMENT_DESCRIPTION = "TreatmentDescription";
            private static final String KEY_TREATMENT_STAFF_NAME_ADD = "TreatmentAddedBy" ;
            private static final String KEY_TREATMENT_TODO_DATE = "Date";

            private static final String KEY_TIMESTAMP_NAME = "TimeStampName";
            private static final String KEY_TIMESTAMP1 = "TimeStamp1";
            private static final String KEY_TIMESTAMP2 = "TimeStamp2";
            private static final String KEY_TIMESTAMP3 = "TimeStamp3";
            private static final String KEY_TIMESTAMP4 = "TimeStamp4";
            private static final String KEY_TIMESTAMP5 = "TimeStamp5";
            private static final String KEY_TIMESTAMP6 = "TimeStamp6";
            private static final String KEY_TIMESTAMP7 = "TimeStamp7";
            private static final String KEY_TIMESTAMP8 = "TimeStamp8";
            private static final String KEY_TIMESTAMP9 = "TimeStamp9";
            private static final String KEY_TIMESTAMP10 = "TimeStamp10";
            private static final String KEY_TIMESTAMP11 = "TimeStamp11";




            private Context context;

            public DataBaseHandler(Context context)//, String name, SQLiteDatabase.CursorFactory factory,int version)
            {
                super(context, DATABASE_NAME, null, DATABASE_VERSION);
                Log.d("Database Operations", "Database Created Successfully!");
                this.context = context;
            }

            @Override
            public void onCreate(SQLiteDatabase db) {

                try {
                    String queryPI = "CREATE TABLE IF NOT EXISTS " + TABLE_PATIENT_INFO + " (" +
                            KEY_PI_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_PI_NAME + " TEXT, " +
                            KEY_PI_AGE + " TEXT, " + KEY_PI_SEX + " TEXT, " +
                            KEY_PI_DOB + " DATETIME, " + KEY_PI_GUARDIAN + " TEXT, " +
                            KEY_PI_WARD + " TEXT, " + KEY_PI_DOCTOR + " TEXT, " +
                            KEY_PI_HEIGHT + " INTEGER, " + KEY_PI_WEIGHT + " INTEGER, " +
                            KEY_PI_DIAGNOSIS + " TEXT, " + KEY_PI_BLOOD + " TEXT, " +
                            KEY_PI_PREVIOUS_CANCER +" TEXT, "+ KEY_PI_PREVIOUS_TREATMENT +" TEXT, "
                            + KEY_PI_CURRENT_MED +" TEXT, "+ KEY_PI_OTHER_MED +" TEXT"+");";

                    String queryHQ = "CREATE TABLE IF NOT EXISTS " + TABLE_QUESTIONS + " (" +
                            KEY_PATIENT_NAME + " TEXT, " + KEY_Q1 + " TEXT, " +
                            KEY_Q2 + " TEXT, " + KEY_Q3 + " TEXT, " +KEY_Q4 + " TEXT, " +
                            KEY_Q5 + " TEXT, " + KEY_Q6 + " TEXT, " + KEY_Q7 + " TEXT, " +
                            KEY_Q8 + " TEXT, " + KEY_Q9 + " TEXT, " + KEY_Q10 + " TEXT, "+
                            KEY_Q11 + " TEXT" + ");";

                    String queryAns = "CREATE TABLE IF NOT EXISTS " + TABLE_ANSWERS + " (" +
                            KEY_ANSWERS_NAME + " TEXT, " + KEY_ANSWERS1 + " TEXT, " +
                            KEY_ANSWERS2 + " TEXT, " + KEY_ANSWERS3 + " TEXT, " +
                            KEY_ANSWERS4 + " TEXT, " + KEY_ANSWERS5 + " TEXT, " +
                            KEY_ANSWERS6 + " TEXT, " + KEY_ANSWERS7 + " TEXT, " +
                            KEY_ANSWERS8 + " TEXT, " + KEY_ANSWERS9 + " TEXT, " +
                            KEY_ANSWERS10 + " TEXT, "+KEY_ANSWERS11 + " TEXT" + ");";

                    String queryHS = "CREATE TABLE " + TABLE_STAFF + " (" +
                            KEY_STAFF_NAME + " TEXT, " + KEY_STAFF_ROLE + " TEXT, "
                        + KEY_STAFF_USER_NAME + " VARCHAR(255), "
                            + KEY_STAFF_PASS_WORD + " VARCHAR(255));";

                    String queryLog = "CREATE TABLE IF NOT EXISTS " + TABLE_LOGINS + "(" +
                            KEY_LOGS_SNAME + " TEXT, " + KEY_LOGS_PNAME + " TEXT, " +
                            KEY_LOGS_TIMESTAMP + " TEXT, " + KEY_LOGS_ACTION
                            + " TEXT" + ");";

                    String queryTreatment = "CREATE TABLE IF NOT EXISTS " + TABLE_TREATMENT + "(" +
                            KEY_TREATMENT_PATIENT_NAME + " TEXT, " + KEY_TREATMENT_STAFF_NAME_ADD + " TEXT, " +
                            KEY_TREATMENT_CATEGORY + " TEXT, " + KEY_TREATMENT_NAME + " TEXT, " +
                            KEY_TREATMENT_DESCRIPTION + " TEXT, " + KEY_TREATMENT_TODO_DATE + " TEXT" + ");";

                    String queryTimeStamp = "CREATE TABLE IF NOT EXISTS " + TABLE_TIMESTAMP + "(" +
                            KEY_TIMESTAMP_NAME + " TEXT, " + KEY_TIMESTAMP1 + " TEXT, "+
                            KEY_TIMESTAMP2 + " TEXT, "+ KEY_TIMESTAMP3 + " TEXT, "+
                            KEY_TIMESTAMP4 + " TEXT, "+ KEY_TIMESTAMP5 + " TEXT, "+
                            KEY_TIMESTAMP6 + " TEXT, "+ KEY_TIMESTAMP7 + " TEXT, "+
                            KEY_TIMESTAMP8 + " TEXT, "+ KEY_TIMESTAMP9 + " TEXT, "+
                            KEY_TIMESTAMP10 + " TEXT, "+ KEY_TIMESTAMP11 + " TEXT"+ ");";

                    db.execSQL(queryHS);
                    db.execSQL(queryPI);
                    db.execSQL(queryHQ);
                    db.execSQL(queryAns);
                    db.execSQL(queryLog);
                    db.execSQL(queryTreatment);
                    db.execSQL(queryTimeStamp);

                    addHospitalStaff(db);
                    addPatientBruce(db);
                    addPreSurgeryQuestions(db);
                    addBruceTreatment(db);
                    addLog(db);
                    addBruceComments(db);
                    addTimeStampBruce(db);

                    ToastMessage.message(context, "Tables Created Successfully!");
                    Log.d("Database Operation", "Tables Created Successfully!");
                }catch (SQLiteException e){
                    ToastMessage.message(context, ""+e);
                    Log.d("Database Operation", ""+e);
                }

            }

            @Override
            public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
                try{
                    ToastMessage.message(context, "OnUpgrade called");
                    db.execSQL("DROP TABLE IF EXISTS " + TABLE_PATIENT_INFO);
                    db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUESTIONS);
                    db.execSQL("DROP TABLE IF EXISTS "+ TABLE_ANSWERS);
                    db.execSQL("DROP TABLE IF EXISTS " + TABLE_COMMENTS);
                    db.execSQL("DROP TABLE IF EXISTS " + TABLE_STAFF );
                    db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGINS );
                    db.execSQL("DROP TABLE IF EXISTS " + TABLE_TREATMENT);
                    Log.d("Database Operation", "onUpgrade method called!");
                    onCreate(db);

                }catch (SQLiteException e){
                    ToastMessage.message(context, ""+e);
                    Log.d("Database Operation", ""+e);
                }
            }

            private void addHospitalStaff(SQLiteDatabase db) {
                try {
                    ContentValues values = new ContentValues();

                    values.put(KEY_STAFF_NAME, "Thomas Kelsey");
                    values.put(KEY_STAFF_ROLE, "Supervisor");
                    values.put(KEY_STAFF_USER_NAME, "tk01");
                    values.put(KEY_STAFF_PASS_WORD, "kelsey");

                    long id = db.insert(TABLE_STAFF, null, values);
                    ToastMessage.message(context, String.valueOf(id));

                    Log.d("Database Operation", "Row " + String.valueOf(id) + "of table Hospital_Staff inserted");
                    values.put(KEY_STAFF_NAME, "Hamish Wallace");
                    values.put(KEY_STAFF_ROLE, "Doctor");
                    values.put(KEY_STAFF_USER_NAME, "hw04");
                    values.put(KEY_STAFF_PASS_WORD, "wallace");
                    db.insert(TABLE_STAFF, null, values);

                    values.put(KEY_STAFF_NAME, "Adebayo Osipitan");
                    values.put(KEY_STAFF_ROLE, "Developer");
                    values.put(KEY_STAFF_USER_NAME, "ao43");
                    values.put(KEY_STAFF_PASS_WORD, "winner");
                    db.insert(TABLE_STAFF, null, values);
                    Log.d("Database Operation", "All rows in table HOSPITAL_STAFF inserted ");
                    // db.close();
                } catch (SQLiteException e) {
                    Log.d("Database Operation", "" + e);
                }
            }

            private void addPreSurgeryQuestions(SQLiteDatabase db){

                try{
                ContentValues values = new ContentValues();

                values.put(KEY_PATIENT_NAME, "Surgery");
                values.put(KEY_Q1, "Has surgery date been confirmed?");
                values.put(KEY_Q2, "Has patient bed been booked?");
                values.put(KEY_Q3, "Has patient/guardian been informed of surgery date?");
                values.put(KEY_Q4, "Has patient FBC, U+E, creat, LFT, blood cross match been checked " +
                        "\nwithin 48 hours of surgery ?");
                values.put(KEY_Q5, "Has patient peripheral coagulation screen been checked, " +
                        "\nand what were results?");
                values.put(KEY_Q6, "Are platelets likely to be needed? If so, state volume.");
                values.put(KEY_Q7, "Is patient on enoxaparin or other drug which must be " +
                        "stopped prior to surgical procedure?");
                values.put(KEY_Q8, "Does patient have an infection requiring special arrangements " +
                        "\nfor theatre eg MRSA, norovirus? If yes state infection and requirements.");
                values.put(KEY_Q9, "Does patient need IV access eg gripper prior to going " +
                        "\nto the anaesthetic room?");
                values.put(KEY_Q10, "Does patient/parent knows arrangements and fasting " +
                        "\ntimes are clear  - 6 hours for milk/solids, 2 hours for water/clear fluid, " +
                        "\nbreast milk?");
                 values.put (KEY_Q11, "Has consultant met with family to do consent");
                    long id = db.insert(TABLE_QUESTIONS, null, values);
                    ToastMessage.message(context, String.valueOf(id));

                    values.put(KEY_PATIENT_NAME, "Line Insertion");
                    values.put(KEY_Q1, "Has Patient been booked on CEPOD?");
                    values.put(KEY_Q2, "Has patient bed been booked?");
                    values.put(KEY_Q3, "Has patient/guardian been informed of procedure date?");
                    values.put(KEY_Q4, "Has patient FBC, U+E, creat, LFT, blood cross match been checked " +
                            "\nwithin 48 hours of surgery ?");
                    values.put(KEY_Q5, "Has patient peripheral coagulation screen been checked, " +
                            "\nand what were results?");
                    values.put(KEY_Q6, "Are platelets likely to be needed? If so, state volume.");
                    values.put(KEY_Q7, "Is patient on enoxaparin or other drug which must be " +
                            "stopped prior to surgical procedure?");
                    values.put(KEY_Q8, "Does patient have Haemophilia and need factor regime");
                    values.put(KEY_Q9, "Does patient have sickle cell disease" +
                            "\n and require admission for IV fluids whilst fasting?");
                    values.put(KEY_Q10, "Does patient/parent knows arrangements and fasting " +
                            "\ntimes are clear  - 6 hours for milk/solids, 2 hours for water/clear fluid, " +
                            "\nbreast milk?");
                    values.put (KEY_Q11, "Has consultant met with family to do consent");
                    db.insert(TABLE_QUESTIONS, null, values);
                    Log.d("Database Operation", "All rows in table HQ_QUESTIONS inserted ");
               // db.close();
            }catch(SQLiteException e){
                    Log.d("Database Operation", ""+e);
                    ToastMessage.message(context, "Database Operation: could not enter data");
            }
            }

            private long addPatientBruce( SQLiteDatabase db){
                try{
                ContentValues values = new ContentValues();

                values.put(KEY_PI_NAME, "BRUCE WAYNE");
                values.put(KEY_PI_AGE, 10);
                values.put(KEY_PI_SEX, "Male");
                values.put(KEY_PI_DOB, "03-10-2005");
                values.put(KEY_PI_GUARDIAN, "Alfred Pennyworth");
                values.put(KEY_PI_WARD, "B-4");
                values.put(KEY_PI_DOCTOR, "Doctor Hugo Strange");
                values.put(KEY_PI_HEIGHT, 150);
                values.put(KEY_PI_WEIGHT,50);
                values.put(KEY_PI_DIAGNOSIS, "Brain Tumor");
                values.put(KEY_PI_BLOOD, "AA");
                values.put(KEY_PI_PREVIOUS_CANCER, "No");
                values.put(KEY_PI_PREVIOUS_TREATMENT, "None");
                values.put(KEY_PI_CURRENT_MED, "Ibuprofen and Paracetamol");
                values.put(KEY_PI_OTHER_MED, "None");

                long id = db.insert(TABLE_PATIENT_INFO, null, values);
                    Log.d("Database Operation", "Bruce Registered Successful");
                return  id;
            }catch(SQLiteException e){
                    Log.d("Database Operation", ""+e);
                return 0;
            }
            }

            private long addBruceTreatment(SQLiteDatabase db){

               try{
                ContentValues values = new ContentValues();

                values.put(KEY_TREATMENT_PATIENT_NAME, "BRUCE WAYNE");
                values.put(KEY_TREATMENT_STAFF_NAME_ADD, "Dr Amanda Wallace");
                values.put(KEY_TREATMENT_CATEGORY, "Surgery");
                values.put(KEY_TREATMENT_NAME, "Brain Tumour Surgery");
                values.put(KEY_TREATMENT_DESCRIPTION, "Remove tumour from brain");
                values.put(KEY_TREATMENT_TODO_DATE, "2015-04-26 23:59");

                Log.d("Database Operation", "Bruce PatientTreatment Registered Successful");
                long id = db.insert(TABLE_TREATMENT, null, values);

                return  id;
            }catch(SQLiteException e){
                return 0;
            }
            }


            private long addLog(SQLiteDatabase db){
               try{
                ContentValues values = new ContentValues();

                values.put(KEY_LOGS_SNAME, "Adebayo Ospitan");
                values.put(KEY_LOGS_PNAME, "BRUCE WAYNE");
                values.put(KEY_LOGS_TIMESTAMP, "2015-02-07 08:45");
                values.put(KEY_LOGS_ACTION, "Registered Patient in system!");
                  db.insert(TABLE_LOGINS, null, values);
                   Log.d("Database Operation", "bruce wayne Comments recordings Successful");

                   values.put(KEY_LOGS_SNAME, "Tom Kelsey");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-14 09:15");
                   values.put(KEY_LOGS_ACTION, "Added X-ray Treatment for Bruce Wayne.");
                   db.insert(TABLE_LOGINS, null, values);

                   values.put(KEY_LOGS_SNAME, "Hamish Wallace");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE: Brain Tumour Surgery");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-15 08:45");
                   values.put(KEY_LOGS_ACTION, "Answered Question 1");
                   db.insert(TABLE_LOGINS, null, values);

                   values.put(KEY_LOGS_SNAME, "Adebayo");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE: Brain Tumour Surgery");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-15 08:46");
                   values.put(KEY_LOGS_ACTION, "Answered Question 2");
                   db.insert(TABLE_LOGINS, null, values);

                   values.put(KEY_LOGS_SNAME, "Hamish Wallace");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE: Brain Tumour Surgery");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-15 08:47");
                   values.put(KEY_LOGS_ACTION, "Answered Question 3");
                   db.insert(TABLE_LOGINS, null, values);

                   values.put(KEY_LOGS_SNAME, "Tom Kelsey");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE: Brain Tumour Surgery");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-15 08:48");
                   values.put(KEY_LOGS_ACTION, "Answered Question 4");
                   db.insert(TABLE_LOGINS, null, values);

                   values.put(KEY_LOGS_SNAME, "Hamish Wallace");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE: Brain Tumour Surgery");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-15 08:49");
                   values.put(KEY_LOGS_ACTION, "Answered Question 5");
                   db.insert(TABLE_LOGINS, null, values);

                   values.put(KEY_LOGS_SNAME, "Hamish Wallace");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE: Brain Tumour Surgery");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-15 08:50");
                   values.put(KEY_LOGS_ACTION, "Answered Question 6");
                   db.insert(TABLE_LOGINS, null, values);

                   values.put(KEY_LOGS_SNAME, "Hamish Wallace");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE: Brain Tumour Surgery");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-15 08:51");
                   values.put(KEY_LOGS_ACTION, "Answered Question 7");
                   db.insert(TABLE_LOGINS, null, values);

                   values.put(KEY_LOGS_SNAME, "Hamish Wallace");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE: Brain Tumour Surgery");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-15 08:52");
                   values.put(KEY_LOGS_ACTION, "Answered Question 8");
                   db.insert(TABLE_LOGINS, null, values);

                   values.put(KEY_LOGS_SNAME, "Hamish Wallace");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE: Brain Tumour Surgery");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-15 08:53");
                   values.put(KEY_LOGS_ACTION, "Answered Question 9");
                   db.insert(TABLE_LOGINS, null, values);

                   values.put(KEY_LOGS_SNAME, "Hamish Wallace");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE: Brain Tumour Surgery");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-15 08:54");
                   values.put(KEY_LOGS_ACTION, "Answered Question 10");
                   db.insert(TABLE_LOGINS, null, values);

                   values.put(KEY_LOGS_SNAME, "Hamish Wallace");
                   values.put(KEY_LOGS_PNAME, "BRUCE WAYNE: Brain Tumour Surgery");
                   values.put(KEY_LOGS_TIMESTAMP, "2015-02-15 08:55");
                   values.put(KEY_LOGS_ACTION, "Answered Question 11");
                   long id = db.insert(TABLE_LOGINS, null, values);
                return id;
            }catch(SQLiteException e){
                   Log.d("Database Operation", ""+e);
                return 0;
            }
            }

            public long addBruceComments(SQLiteDatabase db){
                try{
                    ContentValues values = new ContentValues();

                    String[] COLUMN_NAMES_COM = {KEY_ANSWERS_NAME, KEY_ANSWERS1, KEY_ANSWERS2,
                            KEY_ANSWERS3, KEY_ANSWERS4, KEY_ANSWERS5, KEY_ANSWERS6,
                            KEY_ANSWERS7, KEY_ANSWERS8, KEY_ANSWERS9, KEY_ANSWERS10};
                    values.put(COLUMN_NAMES_COM[0], "BRUCE WAYNE: Brain Tumour Surgery");
                    values.put(COLUMN_NAMES_COM[1], "Yes");
                    values.put(COLUMN_NAMES_COM[2],"Yes");
                    values.put(COLUMN_NAMES_COM[3],"Yes");
                    values.put(COLUMN_NAMES_COM[4], "Yes");
                    values.put(COLUMN_NAMES_COM[5], "No");
                    values.put(COLUMN_NAMES_COM[6], "No");
                    values.put(COLUMN_NAMES_COM[7], "No");
                    values.put(COLUMN_NAMES_COM[8], "Not Applicable");
                    values.put(COLUMN_NAMES_COM[9], "Not Applicable");
                    values.put(COLUMN_NAMES_COM[10], "Not Applicable");
                    long id =db.insert(TABLE_ANSWERS, null, values);
                    ToastMessage.message(context, "Database Operation: bruce wayne Comments recordings Successful");
                    Log.d("Database Operation", "bruce wayne Comments recordings Successful");
                    return  id;
                }catch(SQLiteException e){
                    return 0;
                }
            }

            public long addTimeStampBruce(SQLiteDatabase db){
                try{

                    ContentValues values = new ContentValues();

                    values.put(KEY_TIMESTAMP_NAME, "BRUCE WAYNE: Brain Tumour Surgery");
                    values.put(KEY_TIMESTAMP1,"2015-02-15 08:45");
                    values.put(KEY_TIMESTAMP2,"2015-02-15 08:46");
                    values.put(KEY_TIMESTAMP3,"2015-02-15 08:47");
                    values.put(KEY_TIMESTAMP4,"2015-02-15 08:48");
                    values.put(KEY_TIMESTAMP5,"2015-02-15 08:49");
                    values.put(KEY_TIMESTAMP6,"2015-02-15 08:50");
                    values.put(KEY_TIMESTAMP7,"2015-02-15 08:51");
                    values.put(KEY_TIMESTAMP8,"2015-02-15 08:52");
                    values.put(KEY_TIMESTAMP9,"2015-02-15 08:53");
                    values.put(KEY_TIMESTAMP10,"2015-02-15 08:54");
                    long id = db.insert(TABLE_TIMESTAMP, null, values);
                    return  id;
                }catch(SQLiteException e){
                    return 0;
                }
            }
        }

}
