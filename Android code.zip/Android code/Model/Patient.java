package Model;

/**
 * Created by Adebayo on 18/02/2015.
 */
public class Patient {

    private String  patientName,  patientSex, patientDOB, patientBloodType, patientGuardian,
             patientWard, patientDoctor, patientDiagnosis;
    private int patientAge, patientHeight, patientWeight;

    private String previousCancer, previousTreatment,
            currentMedication, otherMedication;

    public String getPreviousCancer() {
        return previousCancer;
    }

    public void setPreviousCancer(String previousCancer) {
        this.previousCancer = previousCancer;
    }

    public String getPreviousTreatment() {
        return previousTreatment;
    }

    public void setPreviousTreatment(String previousTreatment) {
        this.previousTreatment = previousTreatment;
    }

    public String getCurrentMedication() {
        return currentMedication;
    }

    public void setCurrentMedication(String currentMedication) {
        this.currentMedication = currentMedication;
    }

    public String getOtherMedication() {
        return otherMedication;
    }

    public void setOtherMedication(String otherMedication) {
        this.otherMedication = otherMedication;
    }

    public Patient() {

    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public int getPatientAge() {
        return patientAge;
    }

    public void setPatientAge(int patientAge) {
        this.patientAge = patientAge;
    }

    public String getPatientSex() {
        return patientSex;
    }

    public void setPatientSex(String patientSex) {
        this.patientSex = patientSex;
    }

    public String getPatientDOB() {
        return patientDOB;
    }

    public void setPatientDOB(String patientDOB) {
        this.patientDOB = patientDOB;
    }

    public String getPatientGuardian() {
        return patientGuardian;
    }

    public void setPatientGuardian(String patientGuardian) {
        this.patientGuardian = patientGuardian;
    }

    public String getPatientBloodType() {
        return patientBloodType;
    }

    public void setPatientBloodType(String patientBloodType) {
        this.patientBloodType = patientBloodType;
    }

    public String getPatientWard() {
        return patientWard;
    }

    public void setPatientWard(String patientWard) {
        this.patientWard = patientWard;
    }

    public String getPatientDoctor() {
        return patientDoctor;
    }

    public void setPatientDoctor(String patientDoctor) {
        this.patientDoctor = patientDoctor;
    }

    public int getPatientHeight() {
        return patientHeight;
    }

    public void setPatientHeight(int patientHeight) {
        this.patientHeight = patientHeight;
    }

    public int getPatientWeight() {
        return patientWeight;
    }

    public void setPatientWeight(int patientWeight) {
        this.patientWeight = patientWeight;
    }

    public String getPatientDiagnosis() {
        return patientDiagnosis;
    }

    public void setPatientDiagnosis(String patientDiagnosis) {
        this.patientDiagnosis = patientDiagnosis;
    }
}
