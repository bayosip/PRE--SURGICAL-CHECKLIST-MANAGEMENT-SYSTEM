package Model;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by ao43 on 20/03/15.
 */
public class ToastMessage {

    public static void  message (Context context,String message){

        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }
}
